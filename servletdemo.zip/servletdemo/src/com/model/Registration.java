package com.model;

public class Registration {
	
	
	
	private String name;
	private String email;
	private String city;
	private String password;
	public Registration(String name, String email, String city, String password) {
		super();
		this.name = name;
		this.email = email;
		this.city = city;
		this.password = password;
	}
	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}

}
